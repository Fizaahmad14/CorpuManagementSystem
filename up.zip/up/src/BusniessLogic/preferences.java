package BusniessLogic;



public class preferences {
	
	private String name;
	
	public preferences(String name) {
		this.name = name;
	}
	
	public preferences() {
		this.name = null;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


}
