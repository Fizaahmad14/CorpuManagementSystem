package BusniessLogic;

public class InterestedPeopl extends User{

	public InterestedPeopl(int id, String name, String email,String phone, String qualString, String avail, String u, String p) {
		super(id, name, email,phone,qualString, avail,u,p);
		// TODO Auto-generated constructor stub
	}

	public InterestedPeopl() {
		// TODO Auto-generated constructor stub
		super();
	}
	
}
