package BusniessLogic;

public class SessionalStaff extends InterestedPeopl{
	public SessionalStaff(int id, String name, String email,String phone,String qualString, String avail, String u, String p) {
		super(id, name, email,phone,qualString, avail, u, p);
	}
	public SessionalStaff() {
		// TODO Auto-generated constructor stub
		super();
		
	}
}

