package BusniessLogic;

public class Allocation {

}
