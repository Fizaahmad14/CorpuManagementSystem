package BusniessLogic;

public class Availability {

}
